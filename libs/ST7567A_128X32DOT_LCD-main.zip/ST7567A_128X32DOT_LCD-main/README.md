# ST7567A_128X32DOT_LCD
I2C communication protocol, used to drive the ST7567A 128*32 pixels LCD. 
